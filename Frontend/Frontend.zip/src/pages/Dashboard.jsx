import { useState } from "react";

const Dashboard = () => {
  const [open, setOpen] = useState(false);

  return (
    <div className="w-full text-white min-h-screen bg-[#090713] px-16 py-8">
      <div className="relative flex justify-end items-center">
        {/* Avatar */}
        <div
          className="w-12 h-12 rounded-full border-2 bg-purple-600 border-amber-100  text-white flex justify-center items-center text-xl cursor-pointer"
          onClick={() => setOpen(!open)}
        >
          S
        </div>

        {/* Dropdown */}
        <div
          className={`absolute top-16 right-0 w-45 bg-[#150F2A] rounded-xl shadow-lg  p-2  transition-all duration-300 ${
            open
              ? "opacity-100 scale-100"
              : "opacity-0 scale-95 pointer-events-none"
          }}`}
          onMouseLeave={() => setOpen(false)}
        >
          <p className="px-3 py-2 rounded-lg  hover:bg-[#090713] cursor-pointer">
            Profile
          </p>

          <button
            className="w-full text-left px-3 py-2 rounded-lg text-red-500 hover:bg-[#090713] cursor-pointer"
          >
            Logout
          </button>
        </div>
      </div>

      <div>
        <h1 className="text-center">Hello!</h1>
      </div>
    </div>
  );
};

export default Dashboard;
