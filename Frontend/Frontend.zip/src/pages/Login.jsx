import { useNavigate } from "react-router-dom";

const Login = () => {

    const navigate = useNavigate();

  return (
    <div className="w-full min-h-screen bg-gray-200 flex justify-center items-center">
      <form
        className="w-[350px] h-[400px]  flex flex-col gap-4  rounded-xl bg-white px-8 py-2"
      >
        <h2 className="text-center font-medium text-2xl mt-4 text-[#283346]">
          Login
        </h2>
        <input
          type="email"
          placeholder="Email"
          required
          className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
        />
        <input
          type="password"
          placeholder="Password"
          required
          className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "

        />
        <button
          type="submit"
          className="bg-amber-200 py-4 cursor-pointer rounded-lg"
        >
          Login
        </button>
        <p className="text-center">
          Does't have an account?
          <span
            className="cursor-pointer hover:underline text-blue-500"
            onClick={()=>navigate('/signup')}
          >
            Signup
          </span>
        </p>
      </form>
    </div>
  );
};

export default Login;
