import {useNavigate } from "react-router-dom";

const Signup = () => {
    const navigate= useNavigate();
  return (
    <div className="w-full min-h-screen bg-gray-200 flex justify-center items-center">
      <form className="w-87.5 h-110  flex flex-col gap-4  rounded-xl bg-white px-8 py-2 ">
        <div className="flex flex-col justify-center items-center gap-4">
          <h2 className="text-center font-medium text-2xl mt-4 text-[#283346]">
            Signup
          </h2>
        </div>
        <div className="w-full flex  gap-2">
          <input
            type="text"
            placeholder="First Name"
            required
            className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
          />
          <input
            type="text"
            placeholder="Last Name"
            required
            className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
          />
        </div>
        <select
          className=" border cursor-pointer border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
          required
        >
          <option value="" className="text-gray-400">
            Select Course
          </option>
          <option value="BCA">BCA</option>
          <option value="MCA">MCA</option>
          <option value="BTech CSE">BTech CSE</option>
          <option value="MTech">MTech</option>
          <option value="BBA">BBA</option>
        </select>
        <input
          type="email"
          placeholder="Email"
          required
          className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
        />
        <input
          type="password"
          placeholder="Password"
          required
          className=" border border-gray-400 text-gray-900 w-full px-3 rounded-lg outline-none py-2 "
        />
        <button
          type="submit"
          className="bg-amber-200 py-4 cursor-pointer rounded-lg"
        >
          Signup
        </button>
        <p className="text-center">
          Already have an account?
          <span className="cursor-pointer hover:underline text-blue-500" onClick={()=>navigate('/login')}>
            Login
          </span>
        </p>
      </form>
    </div>
  );
};

export default Signup;
